import xml.etree.cElementTree as ET

tree1 = ET.parse('out.xml')
tree2 = ET.parse('test.xml')

def compare(num):
    for node1 in tree1.iter('formula'):
        if node1.attrib.get('id')==num:
            for node2 in tree2.iter('formula'):
                 for elem1,elem2 in zip(node1.iter(),node2.iter()):
                         if elem1.tag=="formula" or elem1.tag=="eq":
                             continue
                         if elem1.tag!=elem2.tag:
                             return 0

                         if elem1.tag=="mo":
                             if elem1.text!=elem2.text:
                                 return 0

    return 1
                     
count=0    
f=open("out.xml","r",encoding="utf8")
for line in f:
    if '<math>' in line:
        count=count+1
f.close()

for i in range(count):
    val=compare(str(i+1))
    if val==1:
        print('Похожа формула '+str(i+1))
