from bs4 import BeautifulSoup
from bs4.element import Comment
import urllib.request


def tag_visible(element):
    if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
        return False
    if isinstance(element, Comment):
        return False
    return True


def text_from_html(body):
    soup = BeautifulSoup(body, 'html.parser')
    texts = soup.findAll(text=True)
    visible_texts = filter(tag_visible, texts)
    str1=" "

    for item in soup.find("div", {"id": "mw-content-text"}):
           if item.find_all("p"):
                if item.find("img"):
                    b=item.text.split('\n')
            
                    for d in  range(len(b)):
                        if len(b[d])>1:
                            str1=str1+b[d]+'\n'

                    continue

               
                str1=str1+item.text+'\n'


          
    return str1


def get_link(page):
    soup = BeautifulSoup(page,'html.parser')
    all_links=soup.find_all("a")
    for link in all_links:
        try:
            title = link.get('title')
            if "Редактировать" in title or "Википедия" in title or "None" in title or "отсутствует" in title:
                continue
            f=open(str(title)+".txt","w",encoding="utf8")
        except:
            continue
        
        if link.get("href")!=None:
            try:
                html = urllib.request.urlopen('https://ru.wikipedia.org/'+link.get("href"))
                st=text_from_html(html)
                f.write(st)
                
            except:
                html = urllib.request.urlopen('https:'+link.get("href"))
                st=text_from_html(html)
                f.write(st)
                
                

    f.close()
    print('finished')

html = urllib.request.urlopen('https://ru.wikipedia.org/wiki/%D0%9D%D0%B5%D1%80%D0%B0%D0%B2%D0%B5%D0%BD%D1%81%D1%82%D0%B2%D0%BE_%D0%A7%D0%B5%D0%B1%D1%8B%D1%88%D1%91%D0%B2%D0%B0').read()
get_link(html)

