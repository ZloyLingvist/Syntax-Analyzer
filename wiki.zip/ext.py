import xml.etree.cElementTree as ET

tree = ET.parse('Result.xml')

str1=''
ans=[]


n_arr=["case","gender","is_singular","is_proper","is_animate","gender"]
v_arr=["person","is_singular","verb_action_type","is_active_voice","is_perfective_verb","is_transitive_verb","mood","tense"]
a_arr=["gender","is_singular","form","adjective_degree_of_comparison"]
num_arr=["case","numeral_type"]

name1=['Noun','Verb','Conjunction','Adjective','AdverbialPronoun','Preposition','Numeral']
name2=['S','V','CONJ','A','AdverbialPronoun','PR','NUM']

part_of_speach=''

def print_par(str1,str2,str3):
     if str1=="true":
         str4=str2+' '
     else:
         str4=str3+' '

     return str4;


str1=''
i=0


def give_sp(num):
    for node in tree.iter('sentence_element'):
        if node.attrib.get('id')==num:
            for elem in node.iter():
                if not elem.tag==node.tag:
                        if (elem.tag=="syntactic_parent"):
                            if elem.attrib.get('word_id')!=None:
                                return elem.attrib.get('word_id')


def give_id(num):
    for node in tree.iter('sentence_element'):
        if node.attrib.get('id')==num:
             for elem in node.iter():
                if not elem.tag==node.tag:
                    if (elem.tag=="order"):
                        return elem.text
                    

k=0
for node in tree.iter('sentence_element'):
    for elem in node.iter():
        if not elem.tag==node.tag:
            if (elem.tag=="order"):
                str1=str1+elem.text+'\t'
                k=int(elem.text)
                
            if (elem.tag=="text"):
                str1=str1+elem.text+'\t'
                if elem.text==".":
                    str1=str1+".\tSENT\tSENT\t"+str(k-1)+"\tpunc\n\n"
                if elem.text==",":
                    str1=str1+",\tSENT\tSENT\t"+str(k-1)+"\tpunc\n"
                if elem.text=="—":
                    str1=str1+"—\tSENT\tSENT\t"+str(k-1)+"\tpunc\n"

            if elem.tag=="lemma":
                str1=str1+elem.text+'\t'
                    
            if (elem.tag=="part_of_speech"):
                for i in range(len(name1)):
                    if elem.text==name1[i]:
                        str1=str1+name2[i]+'\t'
                        part_of_speach=name2[i]

                if part_of_speach=="PR":
                    str1=str1+"PR"+'\t'

                if part_of_speach=="CONJ":
                    str1=str1+"CONJ"+'\t'

                if part_of_speach=="AdverbialPronoun":
                    str1=str1+"AdverbialPronoun"+'\t'
                        
            if part_of_speach=="S":
                for i in range(len(n_arr)):
                    if elem.tag==n_arr[i]:
                        if i==0:
                            str1=str1+elem.text+' '
                            
                        if i==1:
                            if elem.text=="Masculine":
                               str1=str1+"m"+' '
   
                        if i==2:
                            str1=str1+print_par(elem.text,"sg","pl")
                        if i==3:
                            str1=str1+print_par(elem.text,"proper","common")
                        if i==4:
                            str1=str1+print_par(elem.text,"anim","inan")

            if part_of_speach=="A":
                for i in range(len(a_arr)):
                    if elem.tag==a_arr[i]:
                        if i==0:
                            if elem.text=="Masculine":
                               str1=str1+"m"+' '
                            
                        if i==1:
                            str1=str1+print_par(elem.text,"sg","pl")
                        if i==2:
                             if elem.text=="Short":
                               str1=str1+"brev"+' '
                        if i==3:
                             if elem.text=="Positive":
                               str1=str1+"positive"+' '

            if part_of_speach=="V":
                for i in range(len(v_arr)):
                    if elem.tag==v_arr[i]:
                        if i==0:
                            if elem.text=="Third":
                               str1=str1+"3p"+' '
                            if elem.text=="Second":
                               str1=str1+"2p"+' '
                            if elem.text=="First":
                               str1=str1+"1p"+' '

                        if i==1:
                            str1=str1+print_par(elem.text,"sg","pl")
                               
                        if i==2:
                            if elem.text=="Stative":
                               str1=str1+"Stative"+' '
                            
                        if i==3:
                            str1=str1+print_par(elem.text,"act","med")
                            
                        if i==4:
                            str1=str1+print_par(elem.text,"pf","ipf")

                        if i==5:
                            str1=str1+print_par(elem.text,"tran","int")

                        if i==6:
                            if elem.text=="Indicative":
                               str1=str1+"indic"+' '

                        if i==7:
                            if elem.text=="Present":
                               str1=str1+"praes"+' '

            if part_of_speach=="NUM":
                if elem.tag==num_arr[0]:
                    str1=str1+elem.text+' '

                if elem.tag==num_arr[1]:
                    str1=str1+elem.text+' '

                

                                        
            if (elem.tag=="syntactic_role"):
                if give_id(give_sp(node.attrib.get('id')))!=None:
                        str1=str1+give_id(give_sp(node.attrib.get('id')))+'\t'+elem.text+'\n'
                else:
                        str1=str1+"0"+'\t'+elem.text+'\n'


            ans.append(str1)
            str1=''
                        
      
            
         
fout= open('text.txt', 'w',encoding="utf8")          

for i in range(len(ans)):     
    fout.write(str(ans[i]))
        
fout.close()
